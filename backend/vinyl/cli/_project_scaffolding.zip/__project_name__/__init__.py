from vinyl.lib.definitions import load_defs

defs = load_defs()
