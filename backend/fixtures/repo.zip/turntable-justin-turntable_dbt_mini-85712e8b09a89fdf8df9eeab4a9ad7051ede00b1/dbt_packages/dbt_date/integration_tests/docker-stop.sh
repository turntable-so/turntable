docker-compose down && rm -rf ./.hive-metastore/  && rm -rf ./.spark-warehouse/
