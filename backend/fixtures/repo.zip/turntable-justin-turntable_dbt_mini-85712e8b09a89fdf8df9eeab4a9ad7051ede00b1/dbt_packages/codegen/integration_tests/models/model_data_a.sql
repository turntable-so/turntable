select 
    * 
from {{ ref('data__a_relation') }}
